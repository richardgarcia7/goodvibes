<div id="copy-line" class="clr">
<div id="copy-structure">
<div id="copy">Copyright &copy; <?php echo date("Y"); ?> <?php if(empty($selectcopy)) { echo "$sitename"; } elseif($selectcopy) { echo "$selectcopy"; } ?>. All Right Reserved.</div>
<div id="powered">Powered By <a href="http://www.joomlaperfect.com" target="_blank">Joomla Perfect</a></div>
</div>
</div>