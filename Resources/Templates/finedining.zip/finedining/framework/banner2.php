<?php if($this->countModules('banner')) : ?>
<div id="banner-outer" class="clr">
<jdoc:include type="modules" name="banner" style="none" />
</div>
<?php endif; ?>